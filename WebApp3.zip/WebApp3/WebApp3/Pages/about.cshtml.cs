using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp3.Pages
{
    public class aboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
