using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp3.Pages
{
    public class ContactModel : PageModel
    {
        public bool hasData=false;
        public string FirstName = " ";
        public string LastName="";
        public string Message = "";
        public void OnGet()
        {

        }
        public void OnPost() { 
        
             hasData = true;
            FirstName = Request.Form["Firstname"];
            LastName = Request.Form["Lastname"];
            Message = Request.Form["Message"];
        }
    }
}
